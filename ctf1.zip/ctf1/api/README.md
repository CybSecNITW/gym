# API Documentation
API Documentation has moved to the [wiki](https://github.com/IRS-Cybersec/ctf_platform/wiki/API-Documentation)
